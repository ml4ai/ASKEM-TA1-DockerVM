def model(x, y, z):
    return x + y - z
