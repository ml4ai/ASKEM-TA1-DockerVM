from model import model

if __name__ == "__main__":
    print(model(1,2,3))

