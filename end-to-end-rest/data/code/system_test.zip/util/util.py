def model_tester(x, y, z, result):
    return x+y-z == result